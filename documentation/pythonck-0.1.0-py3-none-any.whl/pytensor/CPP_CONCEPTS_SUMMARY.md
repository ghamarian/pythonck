# C++ Concepts Summary for PyTensor Implementation

This document summarizes all concepts (classes, structs, functions, enums) from the 12 C++ header files that need to be implemented in Python.

## 1. buffer_view.hpp

### Enums
- `address_space_enum`: generic, global, lds, vgpr
- `memory_operation_enum`: set, add, atomic_add, atomic_max
- `amd_buffer_coherence_enum`: coherence_default, coherence_glc, coherence_slc, coherence_glc_slc

### Template Struct
- `buffer_view<AddressSpace, T, BufferSizeType, InvalidElementUseNumericalZeroValue, Coherence>`
  - Specializations for: generic, global, lds, vgpr address spaces

### Key Methods
- Constructor variants (default, with data pointer, with invalid value)
- `init_raw()`: Initialize for raw operations
- `get_address_space()`: Return address space enum
- `operator[]`, `operator()`: Element access
- `get<X>()`: Vectorized read with OOB checking
- `get_raw<X>()`: Raw vectorized read
- `async_get<X>()`: Async load to LDS
- `async_get_raw<X>()`: Raw async load
- `update<Op, X>()`: Update with operation (set/add/atomic)
- `update_raw<Op, X>()`: Raw update
- `set<X>()`: Vectorized write
- `set_raw<X>()`: Raw vectorized write
- `atomic_add<X>()`, `atomic_add_raw<X>()`: Atomic addition
- `atomic_max<X>()`: Atomic maximum
- `is_static_buffer()`, `is_dynamic_buffer()`: Buffer type queries
- `print()`: Debug printing

### Factory Functions
- `make_buffer_view<AddressSpace>()`: Create buffer view

## 2. tensor_coordinate.hpp

### Classes
- `multi_index<Lengths...>`: Multi-dimensional index
  - Methods: `at()`, `size()`, constructors

### Functions
- `make_multi_index()`: Factory for multi_index
- `to_multi_index()`: Convert array to multi_index
- `get_container_of_multi_index()`: Extract container

## 3. tensor_adaptor_coordinate.hpp

### Template Struct
- `tensor_adaptor_coordinate<TensorAdaptor>`
  - Members: `adaptor_`, `top_index_`, `bottom_index_`
  - Methods: Various getters for indices and adaptor

### Functions
- `make_tensor_adaptor_coordinate()`: Factory function
- `move_tensor_adaptor_coordinate_backward()`: Move coordinate backward
- `move_tensor_adaptor_coordinate_forward()`: Move coordinate forward
- `adaptor_coordinate_is_valid()`: Validity check
- `adaptor_coordinate_is_valid_assuming_top_index_is_valid()`: Optimized validity check

## 4. tensor_descriptor.hpp

### Transform Classes (Abstract Base)
- `base_transform`: Abstract base for all transforms
- `embed_transform<Lengths, Coefficients>`: Strided layout
- `unmerge_transform<Lengths, Coefficients>`: Packed layout
- `offset_transform<Offset>`: Constant offset
- `pass_through_transform<Length>`: Identity transform
- `pad_transform<Lengths, PadLengths>`: Padding transform
- `merge_transform<Lengths>`: Dimension merging
- `replicate_transform<Length>`: Broadcasting

### Transform Methods
- `calculate_bottom_index()`: Transform top to bottom index
- `calculate_top_index()`: Transform bottom to top index (if invertible)
- `get_upper_lengths()`, `get_lower_lengths()`: Dimension info
- Various dimension ID mappings

### Tensor Adaptor
- `tensor_adaptor<Transforms...>`: Chain of transforms
  - Methods for index calculation, dimension queries, validity checks

### Tensor Descriptor
- `tensor_descriptor<TensorAdaptor, ElementSpaceSize>`: Complete descriptor
  - Methods: `calculate_offset()`, `calculate_offset_diff()`, etc.

### Factory Functions
- `make_embed_transform()`, `make_unmerge_transform()`, etc.
- `make_tensor_adaptor()`: Create adaptor from transforms
- `make_naive_tensor_descriptor()`: Simple descriptor
- `make_naive_tensor_descriptor_packed()`: Packed layout
- `make_naive_tensor_descriptor_aligned()`: Aligned layout

## 5. tensor_adaptor.hpp

### Utility Functions
- `make_single_stage_tensor_adaptor()`: Single transform adaptor
- `transform_tensor_adaptor()`: Apply transform to adaptor
- `chain_tensor_adaptors()`: Chain two adaptors
- `chain_tensor_adaptors<Adaptors...>()`: Chain multiple adaptors
- `make_identity_tensor_adaptor()`: Identity adaptor
- `make_transpose_tensor_adaptor()`: Transpose dimensions

## 6. tensor_view.hpp

### Template Struct
- `tensor_view<TensorDesc, BufferView>`
  - Methods: Element access, vectorized operations
  - `get_element()`, `set_element()`: Single element
  - `get_vectorized_elements()`, `set_vectorized_elements()`: Vector access
  - Coordinate-based access methods

### Null Tensor View
- `null_tensor_view<TensorDesc>`: Placeholder view

### Factory Functions
- `make_tensor_view()`: Create from descriptor and buffer
- `make_naive_tensor_view()`: Simple strided view
- `make_naive_tensor_view_packed()`: Packed view
- `transform_tensor_view()`: Apply transform to view

## 7. tile_distribution.hpp

### Classes
- `tile_distributed_span<Lengths...>`: Distributed span
- `tile_distributed_index<Lengths...>`: Distributed index
- `tile_distribution_encoding`: Encoding for distribution
- `tile_distribution<Adaptor, Descriptor, Encoding>`: Complete distribution

### Key Methods
- Distribution queries and transformations
- Index calculations between P, Y, R, H dimensions
- Span and slice operations

### Factory Functions
- `make_tile_distributed_span()`, `make_tile_distributed_index()`
- `make_tile_distribution_encoding()`
- `make_tile_distribution()`

## 8. tile_distribution_encoding.hpp

### Enhanced Classes
- `tile_distribution_encoding_detail`: Detailed encoding info
- Enhanced `tile_distribution_encoding` with detail computation

### Functions
- `make_embed_tile_distribution_encoding()`: Create embedded encoding
- `make_reduce_tile_distribution_encoding()`: Create reduced encoding
- Various utility functions for encoding manipulation

## 9. static_distributed_tensor.hpp

### Template Struct
- `static_distributed_tensor<TileDistribution, DataType>`
  - Thread-local buffer storage
  - Methods: `operator[]`, `clear()`, `fill()`, `copy()`
  - `get_slice()`, `get_y_slice()`: Slice access

### Factory Function
- `make_static_distributed_tensor()`: Create distributed tensor

## 10. tile_window.hpp

### Template Classes
- `tile_window_with_static_distribution<BottomTensorView, WindowLengths, TileDistribution>`
  - Distributed window access
  - Methods: `load()`, `store()`, `update()`, async variants
  - Raw access methods
  - Window movement

- `tile_window_with_static_lengths<BottomTensorView, WindowLengths>`
  - Simple window without distribution
  - Similar methods to distributed version

### Factory Functions
- `make_tile_window()`: Create appropriate window type
- `move_tile_window()`: Move window position

## 11. store_tile.hpp

### Functions
- `store_tile()`: Store distributed tensor to window
- `store_tile_raw()`: Raw store operation
- `update_tile()`: Accumulate to window
- `update_tile_raw()`: Raw accumulate operation

## 12. sweep_tile.hpp

### Functions
- `sweep_tile_span()`: Sweep over distributed span
- `sweep_tile_uspan()`: Sweep with unpacking
- `sweep_tile()`: General sweep with control

### Template Class
- `tile_sweeper<DistributedTensor>`: Sweeper object
  - Methods: `get_num_of_access()`, `operator()`
  - Supports partial execution

### Factory Function
- `make_tile_sweeper()`: Create sweeper instance

## Common Patterns

1. **Factory Functions**: Most structs have corresponding `make_*` functions
2. **Const/Non-const Overloads**: Many access methods have both versions
3. **Template Parameters**: Heavy use of variadic templates and SFINAE
4. **Compile-time Computation**: Many operations are constexpr
5. **Device/Host Annotations**: CK_TILE_DEVICE, CK_TILE_HOST_DEVICE macros
6. **Raw vs Normal Operations**: Many operations have raw variants for performance 