from typing import List, Tuple
from .tensor_descriptor import TensorAdaptor
from .tensor_coordinate import MultiIndex, set_container_subset, get_container_subset

class TensorAdaptorCoordinate:
    """
    Python equivalent of the C++ tensor_adaptor_coordinate struct.
    It holds the hidden index state of a tensor coordinate.
    """
    def __init__(self, idx_hidden: MultiIndex, adaptor: TensorAdaptor):
        self.idx_hidden = idx_hidden
        self.adaptor = adaptor

    def get_top_index(self) -> MultiIndex:
        return get_container_subset(self.idx_hidden, self.adaptor.get_top_dimension_hidden_ids())

    def get_bottom_index(self) -> MultiIndex:
        return get_container_subset(self.idx_hidden, self.adaptor.get_bottom_dimension_hidden_ids())

def make_tensor_adaptor_coordinate(adaptor: TensorAdaptor, idx_top: MultiIndex) -> TensorAdaptorCoordinate:
    """
    Python equivalent of the C++ make_tensor_adaptor_coordinate function.
    Calculates the initial hidden index based on a top index.
    """
    ndim_hidden = adaptor.get_num_of_hidden_dimension()
    idx_hidden = MultiIndex(ndim_hidden)
    
    set_container_subset(idx_hidden, adaptor.get_top_dimension_hidden_ids(), idx_top)

    # Apply transforms in reverse order
    for itran in range(len(adaptor.transforms) - 1, -1, -1):
        transform = adaptor.transforms[itran]
        dims_low = adaptor.lower_dimension_hidden_idss[itran]
        dims_up = adaptor.upper_dimension_hidden_idss[itran]
        
        idx_up = get_container_subset(idx_hidden, dims_up)
        idx_low = transform.calculate_lower_index(idx_up)
        set_container_subset(idx_hidden, dims_low, idx_low)
        
    return TensorAdaptorCoordinate(idx_hidden, adaptor)

def move_tensor_adaptor_coordinate(coord: TensorAdaptorCoordinate, idx_diff_top: MultiIndex):
    """
    Python equivalent of the C++ move_tensor_adaptor_coordinate function.
    This performs the incremental update in a C++-faithful way.
    """
    adaptor = coord.adaptor
    
    # This will be the new hidden index state, start with a copy
    idx_hidden_new = coord.idx_hidden.copy()

    # 1. Directly update the top-level dimensions in the new hidden index.
    top_ids = adaptor.get_top_dimension_hidden_ids()
    top_subset_old = get_container_subset(coord.idx_hidden, top_ids)
    top_subset_new_vals = [ov + d for ov, d in zip(top_subset_old, idx_diff_top)]
    top_subset_new = MultiIndex(len(top_subset_new_vals), top_subset_new_vals)
    set_container_subset(idx_hidden_new, top_ids, top_subset_new)

    # Initialize hidden diff with the top-level diff for propagation
    idx_diff_hidden = MultiIndex(adaptor.get_num_of_hidden_dimension())
    set_container_subset(idx_diff_hidden, adaptor.get_top_dimension_hidden_ids(), idx_diff_top)

    # 2. Propagate the changes down through the transforms
    for itran in range(len(adaptor.transforms) - 1, -1, -1):
        transform = adaptor.transforms[itran]
        dims_low = adaptor.lower_dimension_hidden_idss[itran]
        dims_up = adaptor.upper_dimension_hidden_idss[itran]
        
        # Get the inputs for the update function
        idx_low_old = get_container_subset(coord.idx_hidden, dims_low)
        idx_diff_up = get_container_subset(idx_diff_hidden, dims_up)

        # The core of the faithful implementation: use incremental update
        idx_low_new, idx_diff_low = transform.update_lower_index(idx_low_old, idx_diff_up)
        
        # Set the results in the new hidden state and the diff tracker
        set_container_subset(idx_hidden_new, dims_low, idx_low_new)
        set_container_subset(idx_diff_hidden, dims_low, idx_diff_low)
        
    # Update the coordinate state to the new state
    coord.idx_hidden = idx_hidden_new 