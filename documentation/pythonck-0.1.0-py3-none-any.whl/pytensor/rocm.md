# ROCm Team Updates

## Team: JAX

### Binh Huu Thanh Binh

- Performance regression from Jax 5.0 to Jax 6.0 ([SWDEV-538249](https://ontrack-internal.amd.com/browse/SWDEV-538249)): Found the root reason, trying to fix.
- ~15-20% perf drop in DLM's model "jax_stable_diffusion" between Jax v0.4.35 and Jax v0.4.31 ([SWDEV-520544](https://ontrack-internal.amd.com/browse/SWDEV-520544)): Fixed and closed.

### Aleksei

- Fixed a failing JAX test, which led to discovery of ineffective handling of `exp2()` method in XLA, and then fixing it by creating a MLIR rewriter that provides an efficient and accurate implementation instead of inefficient and inaccurate.
- Investigating Llama3-8B running on JAX and providing suggestions on which parts should be optimized (No ticket).

## Team: XLA

### Songlin

- Expanded unit test coverage of ROCm-specific XLA code to 100% synced with CUDA based unit tests, approximately over 140 new unit tests are added ([SWDEV-537799](https://ontrack-internal.amd.com/browse/SWDEV-537799)).

### Eetu

- Integrating CK gemm kernels with XLA.

## HipBLASLt (GEMM Tuning)

### Yoel, Danny, Davood

- **Danny (IBM):** Offline tuning (hipblaslt-bench) ([SWDEV-537123](https://ontrack-internal.amd.com/browse/SWDEV-537123)).
- **Davood (Meta + MI300):** Offline tuning (hipblaslt-bench) ([SWDEV-527708](https://ontrack-internal.amd.com/browse/SWDEV-527708)).
- **Yoel (Meta + MI350):** Comparison with MI300 + Tensile tuning ([SWDEV-533358](https://ontrack-internal.amd.com/browse/SWDEV-533358)) (highest priority).
- **Yoel:** Performance analysis versus Tensile tuning for both DP and SK kernels in MI350, adaptation to standalone code (no hipblaslt dependency).

## HipBLASLt (Kernel Selection)

- Kernel selection presentation link ([SharePoint Link](https://amdcloud-my.sharepoint.com/:p:/r/personal/aghamari_amd_com/_layouts/15/Doc.aspx?sourcedoc=%7Bc39689b7-c061-4ac8-8fd3-e3190c211f40%7D&action=edit&wdPreviousSession=1b61b2d0-c818-7d4d-239f-09f4ea33ed4e)).
- Repository: [ROCm/GemmKernelSelection](https://github.com/ROCm/GemmKernelSelection/).

## MIOpen

### Ville

- Add auto deduce split_k for grouped_conv_bwd_wei /grouped_conv_bwd_data ([LWPCK-3195](https://ontrack-internal.amd.com/browse/LWPCK-3195)): Currently MIOpen uses fixed values {1,2,4,8,16,32,64,128} for splitting the implicit GEMM reduction dimension into smaller chunks. The best value is selected from tuning. The idea in this ticket is to calculate the best value internally from the kernel properties, which should improve performance and reduce the number of tunable parameters in MIOpen.
- MI308X efficientnet training is 3 times slower than H20 fwd cases ([LWPCK-3236](https://ontrack-internal.amd.com/browse/LWPCK-3236)): Addressed performance gap between MI308X and H20 by tuning the internal CK parameters for the forward convolutions. This would involve creating new instances of implicit GEMM solvers that are geared towards MI308X.
- Create reference based on splitK instead of calculating atol and rtol for Grouped conv ([LWPCK-3323](https://ontrack-internal.amd.com/browse/LWPCK-3323)): CK test infrastructure improvement to create a more accurate CPU reference algorithm for testing the accuracy of the GPU implementations.

### JeongHyun

- Performance tests (CK does not have any method yet).

## CK Tile

### Sami Aario

- CK tile split-k two stage ([LWPCK-3349](https://ontrack-internal.amd.com/browse/LWPCK-3349)).

### Mohsen

- CK Tile GEMM - clear C tensor for Kbatch > 1 - problem analysis ([LWPCK-3013](https://ontrack-internal.amd.com/browse/LWPCK-3013)).

### Sami Remes

- CK Tile GEMM - optimized LDS layout for non-K major layouts - part2 ([LWPCK-3302](https://ontrack-internal.amd.com/browse/LWPCK-3302)).

### Yash

- [CK tile] 2D Reduction Kernel + tests ([LWPCK-2967](https://ontrack-internal.amd.com/browse/LWPCK-2967)).

### Damien

- CK Tile tall & skinny gemm pipeline - skip A/B LDS second refactoring after review ([LWPCK-3203](https://ontrack-internal.amd.com/browse/LWPCK-3203)).

## Apex and Torch Audio

### Sriram

- **Fixed AMP tests, transformer tests:**
    - Apex unit tests: Handle created for mixed precision training was not released; default torch device was not reset to CPU ([SWDEV-534536](https://ontrack-internal.amd.com/browse/SWDEV-534536), [SWDEV-538671](https://ontrack-internal.amd.com/browse/SWDEV-538671)).
- **Fused Dense - `test_fused_dense_gelu_dense`:**
    - Hipblaslt kernel understanding to fix fused dense issue on MI300 (invalid solution).
    - MI308 error - less precision (currently working on) ([SWDEV-534531](https://ontrack-internal.amd.com/browse/SWDEV-534531), [SWDEV-540029](https://ontrack-internal.amd.com/browse/SWDEV-540029)).
- **Swap Native Fused Rope Kernels with AITER Kernels:**
    - Integrate AITER backend fused rope into apex and provide option for user to switch between native apex and aiter backend ([SWDEV-496182](https://ontrack-internal.amd.com/browse/SWDEV-496182)).
- **Main work currently undergoing:**
    - Refactor Apex build process to use the PyTorch JIT extension flow to reduce wheel creation time from 60 minutes to a few minutes ([ROCm/frameworks-internal #12681](https://github.com/ROCm/frameworks-internal/issues/12681)).
    - Automatic wheel building plan documentation ([ROCm/frameworks-internal #12210](https://github.com/ROCm/frameworks-internal/issues/12210)).
    - Reviewed PR to optimize memory: Instead of allocating memory, use empty ([ROCm/apex #197](https://github.com/ROCm/apex/pull/197)).
- **Torch Audio:**
    - Created PRs for 4 errors.
    - Hipification - 3 modules.
    - Wheel done.
    - Test pass.
    - Working on this issue has been paused due to large refactoring of torchaudio ([pytorch/audio #3902](https://github.com/pytorch/audio/issues/3902)) and a lot of functionality will be deprecated upstream ([SWDEV-532733](https://ontrack-internal.amd.com/browse/SWDEV-532733)).
- **DLM:**
    - PRs created: Installing flash attention, torch audio, importing torch ([SWDEV-538214](https://ontrack-internal.amd.com/browse/SWDEV-538214), [SWDEV-538530](https://ontrack-internal.amd.com/browse/SWDEV-538530), [SWDEV-538419](https://ontrack-internal.amd.com/browse/SWDEV-538419)).
- **PyTorch:**
    - Memory leak issues ([SWDEV-517239](https://ontrack-internal.amd.com/browse/SWDEV-517239), [ROCm/frameworks-internal #12643](https://github.com/ROCm/frameworks-internal/issues/12643)).
    - Memory snapshot code and understanding how to analyze the graph and values to identify modules causing memory leaks.

## Triton

### Juuso, Tianxing, Anh Minh

- Developing and optimizing Triton kernels at the [AITER repo](https://github.com/ROCm/aiter) (production level kernels, which customers can use for their own needs).
- Currently optimizing the GEMM kernels for Llama and DeepSeek memory bound shapes.
- Next, will move to optimizing the MoE kernels.


## Aiter/Asm kernels
### Sergey, Fabian, and Anton

- Following Carlus's onboarding instructions
- An educational repo from our guys (soon will be updated) [repo](https://github.com/fwahlster-amd/asmdocker)
- Integrating in their team has not been successful so far

