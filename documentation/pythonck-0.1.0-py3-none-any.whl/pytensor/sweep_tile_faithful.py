from typing import Callable, List
import numpy as np
from .static_distributed_tensor import StaticDistributedTensor
from .tensor_coordinate import MultiIndex
from .tensor_coordinate_faithful import make_tensor_adaptor_coordinate, move_tensor_adaptor_coordinate

def sweep_tile_faithful(distributed_tensor: StaticDistributedTensor,
                        func: Callable[[List[int]], None]):
    """
    A C++-faithful implementation of sweep_tile that uses incremental
    coordinate updates instead of re-calculation.
    """
    tile_distribution = distributed_tensor.tile_distribution
    y_lengths = tile_distribution.ys_to_d_descriptor.get_lengths()
    num_dims = len(y_lengths)
    total_elements = np.prod(y_lengths)

    if total_elements == 0:
        return

    # 1. Create initial coordinate at the origin [0, 0, ...]
    origin = MultiIndex(num_dims, [0] * num_dims)
    coord = make_tensor_adaptor_coordinate(tile_distribution.ys_to_d_descriptor, origin)

    # 2. Loop through all elements, moving the coordinate each time
    for i in range(total_elements):
        # a. Yield the current coordinate's top index (the Y indices)
        current_y_indices = list(coord.get_top_index())
        func(current_y_indices)

        # b. Stop before the last move
        if i == total_elements - 1:
            break

        # c. Calculate the next logical coordinate to find the step
        next_y_indices = current_y_indices.copy()
        
        # Increment the indices with carry-over logic
        for dim in range(num_dims - 1, -1, -1):
            next_y_indices[dim] += 1
            if next_y_indices[dim] < y_lengths[dim]:
                break
            next_y_indices[dim] = 0
        
        # d. The step is the difference between next and current
        step_values = [n - c for n, c in zip(next_y_indices, current_y_indices)]
        step = MultiIndex(num_dims, step_values)

        # e. Move the coordinate statefully
        move_tensor_adaptor_coordinate(coord, step) 